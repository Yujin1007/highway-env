close all;
% p = original;
% p(2:end,3) = atan2(p(2:end,2)-p(1:end-1,2), p(2:end,1)-p(1:end-1,1));
% original = p;
% p = passive;
% p(2:end,3) = atan2(p(2:end,2)-p(1:end-1,2), p(2:end,1)-p(1:end-1,1));
% passive = p;
% p = aggressive;
% p(2:end,3) = atan2(p(2:end,2)-p(1:end-1,2), p(2:end,1)-p(1:end-1,1));
% aggressive = p;

interval = 20;



hold on;
% grid on;
xlim([0,2500]);
ylim([-4,16]);
plot(original(1:interval:1000,1),original(1:interval:1000,2),'*-','Linewidth',1.5)
plot(passive(1:interval:1000,1),passive(1:interval:1000,2),'o-','Linewidth',1.5)
plot(aggressive(1:interval:1000,1),aggressive(1:interval:1000,2),'d-','Linewidth',1.5)
for i = -2:4:14
    plot([0,2500],[i,i],'k--','Linewidth',0.5);
end

legend('original','passive','aggressive','')


figure;
subplot(3,1,1);
hold on;
% grid on;
xlim([0,2500]);
ylim([-4,16]);
plot(original(1:interval:1000,1),original(1:interval:1000,2),'*-','Linewidth',1.5,'Color',[0 0.4470 0.7410])
for i = -2:4:14
    plot([0,2500],[i,i],'k--','Linewidth',0.5);
end
subplot(3,1,2);
hold on;
% grid on;
xlim([0,2500]);
ylim([-4,16]);
plot(passive(1:interval:1000,1),passive(1:interval:1000,2),'o-','Linewidth',1.5,'Color',[0.8500 0.3250 0.0980])
for i = -2:4:14
    plot([0,2500],[i,i],'k--','Linewidth',0.5);
end
subplot(3,1,3);
hold on;
% grid on;
xlim([0,2500]);
ylim([-4,16]);
plot(aggressive(1:interval:1000,1),aggressive(1:interval:1000,2),'d-','Linewidth',1.5,'Color',[0.9290 0.6940 0.1250])
for i = -2:4:14
    plot([0,2500],[i,i],'k--','Linewidth',0.5);
end


figure;
hold on;
plot_car(original,interval,	[0 0.4470 0.7410]);
plot_car(passive,interval,	[0.8500 0.3250 0.0980]);
plot_car(aggressive,interval,[0.9290 0.6940 0.1250]);


% axis equal;
function plot_car(data,interval,color)
    width = 2;
    length = 5;
    for i = 1:interval:1000
        rotate_rect(data(i,1),data(i,2),width,length,data(i,3),color);
    end

end

function rotate_rect(x,y,w,l,psi,color)
rotate = [cos(psi),-sin(psi);sin(psi),cos(psi)];
car = [-l*0.5,-w*0.5;l*0.5,-w*0.5;l*0.5,w*0.5;-l*0.5,w*0.5];
car = car*rotate;
car = car + [x,y];

patch(car(:,1),car(:,2),color,'EdgeColor','none');

end