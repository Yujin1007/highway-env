%plot 바꿀것 ! 
%0.5M step에 한번씩 최대랑 최소 찍어서 번지게 하고, 평균으로 그리기. 

close all;

fa = 0.2;
lw = 1.3;
range = 50;
figure;
subplot(1,2,1);
hold on;
xlabel('training step');
ylabel('episode length');
plot(cerep.Step,cerep.Value,'LineWidth',lw);
plot(compep.Step,compep.Value,'LineWidth',lw);
xlim([0,max(compreward.Step(end),cerreward.Step(end))]);
% plot(cerep.Step,cerep.Value,'k','LineWidth',2);
% plot(compep.Step,compep.Value,'Color','#A6A6A6','LineWidth',2);
% legend('TD3 + CER','TD3');

subplot(1,2,2);
hold on;
xlabel('training step');
ylabel('episode reward');
plot(cerreward.Step,cerreward.Value,'LineWidth',lw);
plot(compreward.Step,compreward.Value,'LineWidth',lw);

xlim([0,max(compreward.Step(end),cerreward.Step(end))]);
% legend('TD3 + CER','TD3');


figure;
subplot(1,2,1);
hold on;
ep_c = Data(cerep,range);
ep_b = Data(compep,range);
re_c = Data(cerreward,range);
re_b = Data(compreward,range);


p =  ep_c;
patch(vertcat(p(:,1),flip(p(:,1))),vertcat(p(:,2),flip(p(:,3))),...
    'blue','FaceAlpha',fa,'EdgeColor','none');
plot(p(:,1),p(:,4),'Linewidth',2);

p =  ep_b;
patch(vertcat(p(:,1),flip(p(:,1))),vertcat(p(:,2),flip(p(:,3))),...
    'red','FaceAlpha',fa, 'EdgeColor','none');
plot(p(:,1),p(:,4),'Linewidth',2);
legend('','TD3 + CER','','TD3','');
grid on;
xlabel('training step');
ylabel('episode length');
xlim([0,max(compreward.Step(end),cerreward.Step(end))]);
subplot(1,2,2);
hold on;
p =  re_c;
patch(vertcat(p(:,1),flip(p(:,1))),vertcat(p(:,2),flip(p(:,3))),...
    'blue','FaceAlpha',fa,'EdgeColor','none');
plot(p(:,1),p(:,4),'Linewidth',2);
p =  re_b;
patch(vertcat(p(:,1),flip(p(:,1))),vertcat(p(:,2),flip(p(:,3))),...
    'red','FaceAlpha',fa, 'EdgeColor','none');
plot(p(:,1),p(:,4),'Linewidth',2);
legend('','TD3 + CER','','TD3','');
xlabel('training step');
ylabel('episode reward');
xlim([0,max(compreward.Step(end),cerreward.Step(end))]);
grid on;


function [Plot] = Data(data,range)
    iter = fix(height(data)/range);
    Plot = zeros(iter+2,4);
    Plot(1,:) = [data.Step(1), data.Value(1), data.Value(1), data.Value(1)];
    %Step, Min, Max, Avg
    for i = 1:iter
        d = data((i-1)*range+1:i*range,:);
        Plot(i+1,:) = [mean(d.Step),min(d.Value),max(d.Value),mean(d.Value)];
    end
    Plot(end,:) = [data.Step(end), data.Value(end)-50, data.Value(end)+50, data.Value(end)];
end